`timescale 1ns / 1ps

// ================================================================
//  VGA Controller  640x480 @ 60 Hz
//
//  What this draws:
//   1. Score HUD  - 3 yellow digits, top-right, always visible
//   2. Game-over box - when game_over=1:
//        • Orange border
//        • White "GAME" text  (row 1)
//        • White "OVER" text  (row 2)
//        • Yellow 3-digit final score (row 3)
//   3. Paddle, ball, border, background
//
//  Font: 5-wide x 7-tall bitmap, scale-3 for HUD, scale-4 for text
//  All row/col decoding uses integer arithmetic inside functions
//  (no bit-slicing, no wire-level division/modulo).
// ================================================================
module vga_controller (
    input  wire        clk25,
    input  wire        rst,
    input  wire [9:0]  player_x,
    input  wire [9:0]  player_y,
    input  wire [9:0]  player_w,
    input  wire [9:0]  ball_x,
    input  wire [9:0]  ball_y,
    input  wire [9:0]  score,
    input  wire        game_over,

    output reg  [3:0]  vga_r,
    output reg  [3:0]  vga_g,
    output reg  [3:0]  vga_b,
    output reg         vga_hs,
    output reg         vga_vs
);

    // ------------------------------------------------------------
    //  VGA TIMING
    // ------------------------------------------------------------
    localparam H_ACTIVE     = 640;
    localparam H_TOTAL      = 800;
    localparam V_ACTIVE     = 480;
    localparam V_TOTAL      = 525;
    localparam H_SYNC_START = 656;
    localparam H_SYNC_END   = 752;
    localparam V_SYNC_START = 490;
    localparam V_SYNC_END   = 492;

    localparam PLAYER_H = 10;
    localparam BALL_SZ  = 10;
    localparam BORDER   = 4;

    // ------------------------------------------------------------
    //  COUNTERS
    // ------------------------------------------------------------
    reg [9:0] h_cnt, v_cnt;
    always @(posedge clk25 or posedge rst) begin
        if (rst) begin h_cnt<=0; v_cnt<=0; end
        else if (h_cnt == H_TOTAL-1) begin
            h_cnt <= 0;
            v_cnt <= (v_cnt == V_TOTAL-1) ? 10'd0 : v_cnt+1;
        end else
            h_cnt <= h_cnt+1;
    end

    wire [9:0] px = h_cnt;
    wire [9:0] py = v_cnt;
    wire active   = (px < H_ACTIVE) && (py < V_ACTIVE);

    // ------------------------------------------------------------
    //  FONT ROM
    //  18 glyphs × 35 bits.
    //  Glyph index:
    //    0=G 1=A 2=M 3=E   (for "GAME")
    //    4=O 5=V 6=E 7=R   (for "OVER")
    //    8..17 = digits '0'..'9'
    //
    //  Each glyph = 7 rows × 5 cols.
    //  Packed: row0 in bits[34:30], row6 in bits[4:0].
    //  Within a row, col0 = bit4 (MSB), col4 = bit0 (LSB).
    //  Pixel at (row r, col c) = word[(6-r)*5 + (4-c)]
    // ------------------------------------------------------------
    reg [34:0] FONT [0:17];
    initial begin
        FONT[ 0]={5'b01110,5'b10001,5'b10000,5'b10111,5'b10001,5'b10001,5'b01110};//G
        FONT[ 1]={5'b01110,5'b10001,5'b10001,5'b11111,5'b10001,5'b10001,5'b10001};//A
        FONT[ 2]={5'b10001,5'b11011,5'b10101,5'b10001,5'b10001,5'b10001,5'b10001};//M
        FONT[ 3]={5'b11111,5'b10000,5'b11110,5'b10000,5'b10000,5'b10000,5'b11111};//E
        FONT[ 4]={5'b01110,5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b01110};//O
        FONT[ 5]={5'b10001,5'b10001,5'b10001,5'b10001,5'b01010,5'b01010,5'b00100};//V
        FONT[ 6]={5'b11111,5'b10000,5'b11110,5'b10000,5'b10000,5'b10000,5'b11111};//E
        FONT[ 7]={5'b11110,5'b10001,5'b10001,5'b11110,5'b10100,5'b10010,5'b10001};//R
        FONT[ 8]={5'b01110,5'b10001,5'b10011,5'b10101,5'b11001,5'b10001,5'b01110};//0
        FONT[ 9]={5'b00100,5'b01100,5'b00100,5'b00100,5'b00100,5'b00100,5'b01110};//1
        FONT[10]={5'b01110,5'b10001,5'b00001,5'b00110,5'b01000,5'b10000,5'b11111};//2
        FONT[11]={5'b11111,5'b00010,5'b00100,5'b00010,5'b00001,5'b10001,5'b01110};//3
        FONT[12]={5'b00010,5'b00110,5'b01010,5'b10010,5'b11111,5'b00010,5'b00010};//4
        FONT[13]={5'b11111,5'b10000,5'b11110,5'b00001,5'b00001,5'b10001,5'b01110};//5
        FONT[14]={5'b00110,5'b01000,5'b10000,5'b11110,5'b10001,5'b10001,5'b01110};//6
        FONT[15]={5'b11111,5'b00001,5'b00010,5'b00100,5'b01000,5'b01000,5'b01000};//7
        FONT[16]={5'b01110,5'b10001,5'b10001,5'b01110,5'b10001,5'b10001,5'b01110};//8
        FONT[17]={5'b01110,5'b10001,5'b10001,5'b01111,5'b00001,5'b00010,5'b01100};//9
    end

    // font_bit(glyph, row, col) - all integer, no truncation
    function automatic font_bit;
        input integer glyph;
        input integer row;   // 0..6
        input integer col;   // 0..4
        integer idx;
        begin
            idx      = (6-row)*5 + (4-col);   // 0..34
            font_bit = FONT[glyph][idx];
        end
    endfunction

    // ------------------------------------------------------------
    //  SCORE DIGIT DECODE  (no / or %)
    // ------------------------------------------------------------
    wire [3:0] dh = (score>=200) ? 4'd2 : (score>=100) ? 4'd1 : 4'd0;
    wire [9:0] r1 = score - {6'd0,dh}*100;
    wire [3:0] dt = (r1>=90)?4'd9:(r1>=80)?4'd8:(r1>=70)?4'd7:(r1>=60)?4'd6:
                   (r1>=50)?4'd5:(r1>=40)?4'd4:(r1>=30)?4'd3:(r1>=20)?4'd2:
                   (r1>=10)?4'd1:4'd0;
    wire [3:0] du = r1[3:0] - dt*4'd10;

    // ------------------------------------------------------------
    //  GAME OBJECTS
    // ------------------------------------------------------------
    wire in_player    = (player_w>0) &&
                        (px>=player_x) && (px<player_x+player_w) &&
                        (py>=player_y) && (py<player_y+PLAYER_H);
    wire in_player_hi = (player_w>0) &&
                        (px>=player_x) && (px<player_x+player_w) &&
                        (py>=player_y) && (py<player_y+2);
    wire in_ball      = (px>=ball_x) && (px<ball_x+BALL_SZ) &&
                        (py>=ball_y) && (py<ball_y+BALL_SZ);
    wire in_border    = (px<BORDER)||(px>=H_ACTIVE-BORDER)||
                        (py<BORDER)||(py>=V_ACTIVE-BORDER);

    // ============================================================
    //  SECTION 1: HUD SCORE  (top-right, always visible)
    //
    //  Scale = 3  →  each font cell = 3×3 px
    //  One digit = 15 px wide × 21 px tall
    //  3 digits  = 45 px wide
    //  Placed at:  x = 590..634  (right-aligned, 6px from border)
    //              y =   8.. 28  (21 rows, 8px from top border)
    //
    //  Digit regions:
    //    hundreds: px 590..604
    //    tens:     px 605..619
    //    ones:     px 620..634
    // ============================================================

    // All tests are done with plain integer comparisons in a function
    // so there is zero risk of Verilog width truncation.

    function automatic hud_pixel;
        input integer ipx;
        input integer ipy;
        input integer i_dh;   // hundreds digit 0..9
        input integer i_dt;   // tens digit     0..9
        input integer i_du;   // ones digit     0..9
        integer row, col, glyph, xoff;
        begin
            hud_pixel = 0;
            if (ipy >= 8 && ipy < 29) begin          // y in range
                row = (ipy - 8) / 3;                 // 0..6
                // hundreds
                if (ipx >= 590 && ipx < 605) begin
                    col = (ipx - 590) / 3;           // 0..4
                    hud_pixel = font_bit(8 + i_dh, row, col);
                end
                // tens
                else if (ipx >= 605 && ipx < 620) begin
                    col = (ipx - 605) / 3;
                    hud_pixel = font_bit(8 + i_dt, row, col);
                end
                // ones
                else if (ipx >= 620 && ipx < 635) begin
                    col = (ipx - 620) / 3;
                    hud_pixel = font_bit(8 + i_du, row, col);
                end
            end
        end
    endfunction

    wire score_px = hud_pixel(px, py, dh, dt, du);

    // ============================================================
    //  SECTION 2: GAME-OVER BOX
    //
    //  Box:  x 160..479  (320px wide)   y 150..329  (180px tall)
    //
    //  "GAME"  text  - scale 4, 4 chars × 20px = 80px wide
    //    x: 160 + (320-80)/2 = 280 .. 359
    //    y: 170 .. 197  (7 rows × 4px = 28px)
    //
    //  "OVER"  text  - same scale & x
    //    y: 206 .. 233
    //
    //  Score digits - scale 5, 3 digits × 25px = 75px wide
    //    x: 160 + (320-75)/2 = 283 .. 357
    //    y: 255 .. 289  (7 rows × 5px = 35px)
    // ============================================================

    localparam BX0 = 160, BX1 = 480;
    localparam BY0 = 150, BY1 = 330;

    wire in_box = game_over &&
                  (px>=BX0) && (px<BX1) &&
                  (py>=BY0) && (py<BY1);

    wire in_box_border = in_box &&
                         ((px<BX0+4)||(px>=BX1-4)||
                          (py<BY0+4)||(py>=BY1-4));

    function automatic gameover_text_pixel;
        input integer ipx;
        input integer ipy;
        // returns 1 if this pixel is part of "GAME" or "OVER" text
        integer row, col, ch, glyph, xoff;
        begin
            gameover_text_pixel = 0;
            // ---- "GAME" row: y 170..197 ----
            if (ipy >= 170 && ipy < 198) begin
                row = (ipy - 170) / 4;              // 0..6
                if (ipx >= 280 && ipx < 360) begin
                    xoff  = ipx - 280;              // 0..79
                    ch    = xoff / 20;              // 0=G,1=A,2=M,3=E
                    col   = (xoff - ch*20) / 4;    // 0..4
                    gameover_text_pixel = font_bit(ch, row, col);
                end
            end
            // ---- "OVER" row: y 206..233 ----
            else if (ipy >= 206 && ipy < 234) begin
                row = (ipy - 206) / 4;
                if (ipx >= 280 && ipx < 360) begin
                    xoff  = ipx - 280;
                    ch    = xoff / 20;              // 0=O,1=V,2=E,3=R → glyph 4..7
                    col   = (xoff - ch*20) / 4;
                    gameover_text_pixel = font_bit(4 + ch, row, col);
                end
            end
        end
    endfunction

    function automatic gameover_score_pixel;
        input integer ipx;
        input integer ipy;
        input integer i_dh;
        input integer i_dt;
        input integer i_du;
        integer row, col;
        begin
            gameover_score_pixel = 0;
            // score digits: y 255..289
            if (ipy >= 255 && ipy < 290) begin
                row = (ipy - 255) / 5;             // 0..6
                if (ipx >= 283 && ipx < 308) begin
                    col = (ipx - 283) / 5;
                    gameover_score_pixel = font_bit(8 + i_dh, row, col);
                end
                else if (ipx >= 308 && ipx < 333) begin
                    col = (ipx - 308) / 5;
                    gameover_score_pixel = font_bit(8 + i_dt, row, col);
                end
                else if (ipx >= 333 && ipx < 358) begin
                    col = (ipx - 333) / 5;
                    gameover_score_pixel = font_bit(8 + i_du, row, col);
                end
            end
        end
    endfunction

    wire go_text_px  = game_over && gameover_text_pixel(px, py);
    wire go_score_px = game_over && gameover_score_pixel(px, py, dh, dt, du);

    // ============================================================
    //  COLOUR OUTPUT
    // ============================================================
    always @(posedge clk25 or posedge rst) begin
        if (rst) begin
            vga_hs<=1; vga_vs<=1;
            vga_r<=0; vga_g<=0; vga_b<=0;
        end else begin
            vga_hs <= ~(h_cnt>=H_SYNC_START && h_cnt<H_SYNC_END);
            vga_vs <= ~(v_cnt>=V_SYNC_START && v_cnt<V_SYNC_END);

            if (!active) begin
                {vga_r,vga_g,vga_b} <= 12'h000;

            // HUD score - yellow, always on top (outside game-over box)
            end else if (score_px && !in_box) begin
                {vga_r,vga_g,vga_b} <= {4'hF,4'hF,4'h0};

            // ---- game-over overlay ----
            end else if (in_box) begin
                if (in_box_border)
                    {vga_r,vga_g,vga_b} <= {4'hF,4'hA,4'h0};  // orange frame
                else if (go_text_px)
                    {vga_r,vga_g,vga_b} <= {4'hF,4'hF,4'hF};  // white "GAME OVER"
                else if (go_score_px)
                    {vga_r,vga_g,vga_b} <= {4'hF,4'hF,4'h0};  // yellow final score
                else
                    {vga_r,vga_g,vga_b} <= {4'h1,4'h0,4'h2};  // dark purple bg

            // paddle highlight (top 2px)
            end else if (in_player_hi) begin
                {vga_r,vga_g,vga_b} <= {4'h8,4'hF,4'hF};

            // paddle body
            end else if (in_player) begin
                {vga_r,vga_g,vga_b} <= {4'h0,4'hC,4'hC};

            // ball
            end else if (in_ball) begin
                {vga_r,vga_g,vga_b} <= {4'hF,4'hF,4'hF};

            // border
            end else if (in_border) begin
                {vga_r,vga_g,vga_b} <= {4'hA,4'hA,4'hA};

            // background
            end else begin
                {vga_r,vga_g,vga_b} <= {4'h0,4'h1,4'h2};
            end
        end
    end

endmodule